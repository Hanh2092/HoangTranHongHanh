package Baitap_vidu_Chuong6;

public class vidu6_15 {
    public static void main(String[] args) {
        String chuoicha = new String("welcomw to Freetuts.net!");
        String chuoicon1 = chuoicha.substring(11);
        System.out.println(chuoicon1);
        String chuoicon2 = chuoicha.substring(11, 19);
        System.out.println(chuoicon2);
    }
}
