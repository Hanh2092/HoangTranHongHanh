package Baitap_vidu_Chuong6;

public class vidu6_6 {
    public static void main(String[] args) {
        String chuoi = new String("welcome to java!");
        System.out.println(chuoi);
    }
}
