package Baitap_vidu_Chuong6;

public class vidu6_8 {
    public static void main(String[] args) {
        String chuoi1 = "Happy ", chuoi2 = "new year!";
        String chuoi3 = chuoi1.concat(chuoi2);
        System.out.println(chuoi3);
    }
}
