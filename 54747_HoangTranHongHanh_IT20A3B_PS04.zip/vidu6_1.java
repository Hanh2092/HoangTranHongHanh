package Baitap_vidu_Chuong6;

public class vidu6_1 {
    static void p() {
        System.out.println("hello");
        p();
    }

    public static void main(String[] args) {
        p();
    }
}
