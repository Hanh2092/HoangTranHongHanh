package Baitap_vidu_Chuong6;

public class vidu6_14 {
    public static void main(String[] args) {
        String string1 = new String("   welcome to Freetuts.net!   ");
        string1 = string1.trim();
        System.out.println("chuỗi sau khi loại bỏ khoảng trắng thừa là " + string1);
    }
}
