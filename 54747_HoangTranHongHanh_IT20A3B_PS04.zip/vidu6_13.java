package Baitap_vidu_Chuong6;

public class vidu6_13 {
    public static void main(String[] args) {
        String string1 = new String("Happy new year!");
        System.out.println(string1.replace('1', 'r'));
        System.out.println("chuỗi sau khi thay thế là " + string1.replace('y', 'r'));
    }
}
